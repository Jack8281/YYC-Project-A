/*
 * YYC Job Control – chatbot widget (MOCK version, no backend, no Firebase).
 * Usage:  <link rel="stylesheet" href="chatbot.css">
 *         <script src="chatbot.js" defer></script>
 * Optional: window.YYCChat.init({ title: "...", getReply: async (text) => "..." })
 *
 * To connect a real AI later, pass your own getReply(text) that calls a Cloud Function.
 * NEVER put an AI API key in this file.
 */
(function () {
  "use strict";

  const SUGGESTIONS = ["Which jobs are delayed?", "How do I reassign a job?", "What are the job stages?", "Show my workload"];

  // ---- MOCK replies: replace with a real backend call later ----
  const MOCK_RULES = [
    { match: /delay|late|overdue/i, reply: "Mock data: 3 jobs are past their target date.\n• ABC Sdn Bhd (Audit) – 5 days late\n• XYZ Bhd (Tax) – 2 days late\n• Lim & Co (Tax) – 1 day late" },
    { match: /reassign|transfer|handover/i, reply: "To reassign a job, open it from your team list, choose a new preparer, and confirm. Only managers can do this." },
    { match: /stage|workflow|status/i, reply: "Jobs move through: Preparation → Review → Amendments → Draft to client → Client review → Submission." },
    { match: /workload|my jobs|assigned/i, reply: "Mock data: you currently hold 12 jobs – 7 in Preparation, 3 in Review, 2 in Amendments." },
    { match: /thank|thanks|thx|tq/i, reply: "You're welcome! Let me know if you need anything else." },
    { match: /bye|goodbye|see you|cya/i, reply: "Goodbye! Have a great day." },
    { match: /who are you|what can you do|help/i, reply: "I'm the YYC assistant (demo). I can answer questions about delayed jobs, reassigning jobs, job stages and your workload." },
    { match: /hello|hi\b|hey/i, reply: "Hi! I'm the YYC assistant. Ask me about jobs, stages or workload." },
  ];
  const FALLBACK = "I'm only a demo right now, so I can't answer that yet. Try one of the suggestions below the chat.";

  async function defaultGetReply(text) {
    await new Promise((r) => setTimeout(r, 700 + Math.random() * 600)); // fake thinking time
    const rule = MOCK_RULES.find((x) => x.match.test(text));
    return rule ? rule.reply : FALLBACK;
  }

  const ICON_CHAT = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12a8 8 0 0 1-11.6 7.1L4 20l1-4.6A8 8 0 1 1 21 12z"/></svg>';
  const ICON_BOT = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="8" width="16" height="11" rx="3"/><path d="M12 8V5M9 13h.01M15 13h.01"/></svg>';

  function el(tag, cls, html) {
    const e = document.createElement(tag);
    if (cls) e.className = cls;
    if (html != null) e.innerHTML = html;
    return e;
  }
  function timeNow() {
    return new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
  }

  function init(options) {
    if (document.querySelector(".yyc-chat")) return; // already mounted
    const opts = Object.assign({ title: "YYC Assistant", subtitle: "demo mode", getReply: defaultGetReply }, options || {});

    const root = el("div", "yyc-chat");
    const launcher = el("button", "yyc-chat__launcher", ICON_CHAT);
    launcher.type = "button";
    launcher.setAttribute("aria-label", "Open chat assistant");

    const panel = el("section", "yyc-chat__panel");
    panel.setAttribute("role", "dialog");
    panel.setAttribute("aria-label", opts.title);

    const header = el("div", "yyc-chat__header");
    const avatar = el("div", "yyc-chat__avatar", ICON_BOT);
    const titles = el("div");
    const title = el("div", "yyc-chat__title"); title.textContent = opts.title;
    const sub = el("div", "yyc-chat__sub"); sub.textContent = opts.subtitle;
    titles.append(title, sub);
    const closeBtn = el("button", "yyc-chat__close", "&times;");
    closeBtn.type = "button"; closeBtn.setAttribute("aria-label", "Close chat");
    header.append(avatar, titles, closeBtn);

    const messages = el("div", "yyc-chat__messages");
    messages.setAttribute("aria-live", "polite");
    const chips = el("div", "yyc-chat__chips");

    const form = el("form", "yyc-chat__form");
    const input = el("input", "yyc-chat__input");
    input.type = "text"; input.placeholder = "Ask about jobs, stages, workload…"; input.autocomplete = "off";
    input.setAttribute("aria-label", "Message");
    const send = el("button", "yyc-chat__send", "Send");
    send.type = "submit";
    form.append(input, send);
    const note = el("div", "yyc-chat__note"); note.textContent = "Demo responses – not real job data.";

    panel.append(header, messages, chips, form, note);
    root.append(panel, launcher);
    document.body.appendChild(root);

    function addMessage(text, who) {
      const m = el("div", "yyc-chat__msg yyc-chat__msg--" + who);
      const body = el("div"); body.textContent = text;
      const t = el("div", "yyc-chat__time"); t.textContent = timeNow();
      m.append(body, t);
      messages.appendChild(m);
      messages.scrollTop = messages.scrollHeight;
      return m;
    }
    function addTyping() {
      const m = el("div", "yyc-chat__msg yyc-chat__msg--bot", '<div class="yyc-chat__typing"><span></span><span></span><span></span></div>');
      messages.appendChild(m);
      messages.scrollTop = messages.scrollHeight;
      return m;
    }

    async function handle(text) {
      text = text.trim();
      if (!text) return;
      addMessage(text, "user");
      input.value = ""; send.disabled = true; input.disabled = true;
      const typing = addTyping();
      let reply;
      try { reply = await opts.getReply(text); }
      catch (err) { reply = "Sorry, something went wrong. Please try again."; }
      typing.remove();
      addMessage(reply, "bot");
      send.disabled = false; input.disabled = false; input.focus();
    }

    SUGGESTIONS.forEach((s) => {
      const c = el("button", "yyc-chat__chip"); c.type = "button"; c.textContent = s;
      c.addEventListener("click", () => handle(s));
      chips.appendChild(c);
    });

    function setOpen(open) {
      root.classList.toggle("is-open", open);
      launcher.setAttribute("aria-label", open ? "Close chat assistant" : "Open chat assistant");
      if (open) input.focus();
    }
    launcher.addEventListener("click", () => setOpen(!root.classList.contains("is-open")));
    closeBtn.addEventListener("click", () => setOpen(false));
    document.addEventListener("keydown", (e) => { if (e.key === "Escape") setOpen(false); });
    form.addEventListener("submit", (e) => { e.preventDefault(); handle(input.value); });

    addMessage("Hi! I'm the YYC assistant (demo). What would you like to know?", "bot");
  }

  window.YYCChat = { init: init };
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", () => init());
  else init();
})();
